<?php

/**
 * JobFit AI - File Upload Handler
 * Handles resume file uploads and text extraction
 */

require_once 'config.php';

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Check if file was uploaded
    if (!isset($_FILES['resume']) || $_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error occurred');
    }

    $file = $_FILES['resume'];

    // Validate file size
    if ($file['size'] > MAX_FILE_SIZE) {
        throw new Exception('File size exceeds maximum limit of 5MB');
    }

    // Validate file extension
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($fileExtension, ALLOWED_EXTENSIONS)) {
        throw new Exception('Invalid file type. Only PDF and TXT files are allowed');
    }

    // Extract text based on file type
    $extractedText = '';

    if ($fileExtension === 'txt') {
        $extractedText = file_get_contents($file['tmp_name']);
    } elseif ($fileExtension === 'pdf') {
        $extractedText = extractTextFromPDF($file['tmp_name']);
    }

    if (empty(trim($extractedText))) {
        throw new Exception('Could not extract text from file. Please ensure the file contains readable text.');
    }

    // Return extracted text
    echo json_encode([
        'success' => true,
        'text' => $extractedText,
        'filename' => $file['name']
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

/**
 * Extract text from PDF file
 * Note: This is a basic implementation. For production, consider using libraries like:
 * - Smalot\PdfParser
 * - pdftotext command-line tool
 */
function extractTextFromPDF($filePath)
{
    // Check if pdftotext is available (Linux/Mac)
    if (function_exists('shell_exec') && !empty(shell_exec('which pdftotext'))) {
        $output = shell_exec("pdftotext '$filePath' -");
        if (!empty($output)) {
            return $output;
        }
    }

    // Fallback: Basic PDF text extraction
    // This works for simple PDFs but may not work for complex layouts
    $content = file_get_contents($filePath);

    // Remove binary data and extract text
    $text = '';
    if (preg_match_all('/\(([^)]+)\)/i', $content, $matches)) {
        $text = implode(' ', $matches[1]);
    }

    // Alternative: Try to extract text between stream markers
    if (empty($text)) {
        if (preg_match_all('/stream\s*(.+?)\s*endstream/s', $content, $matches)) {
            foreach ($matches[1] as $stream) {
                // Remove non-printable characters
                $cleaned = preg_replace('/[^\x20-\x7E\n\r]/', ' ', $stream);
                $text .= ' ' . $cleaned;
            }
        }
    }

    // Clean up extracted text
    $text = preg_replace('/\s+/', ' ', $text);
    $text = trim($text);

    if (empty($text)) {
        throw new Exception('PDF text extraction failed. Please use a text-based PDF or upload a TXT file instead.');
    }

    return $text;
}
