<?php

/**
 * JobFit AI - Configuration File
 * Contains database and API configuration
 * IMPORTANT: Never commit this file with real credentials to version control
 */

// Error reporting for development (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Update with your MySQL password
define('DB_NAME', 'jobfit');

// Google Gemini API Configuration
// Get your API key from: https://aistudio.google.com/app/apikey
define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY_HERE'); // REPLACE THIS

define('GEMINI_API_URL', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// File Upload Configuration
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['pdf', 'txt']);

// CORS Headers (for local development)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Database Connection Function
function getDBConnection()
{
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        if ($conn->connect_error) {
            throw new Exception("Database connection failed: " . $conn->connect_error);
        }

        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Database connection error. Please check configuration.'
        ]);
        exit;
    }
}

// Validate API Key Configuration
function validateAPIKey()
{
    if (empty(GEMINI_API_KEY) || GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Gemini API key not configured. Please update config.php'
        ]);
        exit;
    }
}
