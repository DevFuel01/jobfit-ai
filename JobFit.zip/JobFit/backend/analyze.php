<?php

/**
 * JobFit AI - Analysis Endpoint
 * Handles resume analysis using Google Gemini API
 */

require_once 'config.php';

// Validate API key is configured
validateAPIKey();

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Get input data
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        throw new Exception('Invalid JSON input');
    }

    $resumeText = trim($input['resume_text'] ?? '');
    $jobDescription = trim($input['job_description'] ?? '');

    // Validate input
    if (empty($resumeText)) {
        throw new Exception('Resume text is required');
    }

    if (empty($jobDescription)) {
        throw new Exception('Job description is required');
    }

    // Construct Gemini API prompt
    $prompt = buildAnalysisPrompt($resumeText, $jobDescription);

    // Call Gemini API
    $analysisResult = callGeminiAPI($prompt);

    // Parse and validate JSON response
    $analysis = parseAnalysisResult($analysisResult);

    // Store in database
    $analysisId = storeAnalysis($resumeText, $jobDescription, $analysis);

    // Return success response
    echo json_encode([
        'success' => true,
        'analysis_id' => $analysisId,
        'data' => $analysis
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

/**
 * Build the analysis prompt for Gemini API
 */
function buildAnalysisPrompt($resumeText, $jobDescription)
{
    return "You are an AI resume analyst. Compare the provided RESUME and JOB DESCRIPTION semantically.
Analyze skill alignment, identify gaps, and provide improvement opportunities.

ETHICAL GUIDELINES:
- Focus ONLY on professional skills, experience, and qualifications.
- Do NOT make assumptions based on gender, age, ethnicity, name, or personal identity.
- Provide objective, constructive feedback.

CRITICAL INSTRUCTION:
Return ONLY valid JSON.
- **MUST use DOUBLE QUOTES (\") for all keys and string values.** (e.g. \"key\": \"value\")
- **CRITICAL: ESCAPE ANY DOUBLE QUOTES inside string values.** (e.g. \"experience with \\\"cloud\\\" solutions\")
- Do NOT use markdown formatting.
- Do NOT use trailing commas.
- Ensure all strings are single-line.
- **Keep lists concise (max 10 items).**

Response Format:
{
  \"fit_score\": <number 0-100>,
  \"matched_skills\": [<array of strings>],
  \"missing_skills\": [<array of strings>],
  \"recommendations\": [<array of strings>],
  \"summary\": \"<One short, punchy paragraph (max 2 sentences). Start with 'You are a [High/Moderate/Low] fit'. Mention 1 key strength and 1 key area to improve.>\"
}

RESUME:
$resumeText

JOB DESCRIPTION:
$jobDescription";
}

/**
 * Call Google Gemini API
 */
function callGeminiAPI($prompt)
{
    $url = GEMINI_API_URL . '?key=' . GEMINI_API_KEY;

    $data = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $prompt]
                ]
            ]
        ],
        'generationConfig' => [
            // Lower temperature for more deterministic/compliant output
            'temperature' => 0.2,
            'topK' => 32,
            'topP' => 1,
            'maxOutputTokens' => 8192,
        ]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch)) {
        throw new Exception('API request failed: ' . curl_error($ch));
    }

    curl_close($ch);

    if ($httpCode !== 200) {
        $errorDetails = json_decode($response, true);
        $errorMessage = 'API returned error code: ' . $httpCode;
        if (isset($errorDetails['error']['message'])) {
            $errorMessage .= ' - ' . $errorDetails['error']['message'];
        }
        throw new Exception($errorMessage);
    }

    $result = json_decode($response, true);

    if (!isset($result['candidates'][0]['content']['parts'][0]['text'])) {
        throw new Exception('Invalid API response structure. Response: ' . substr($response, 0, 200));
    }

    return $result['candidates'][0]['content']['parts'][0]['text'];
}



/**
 * Parse and validate analysis result from Gemini
 */
function parseAnalysisResult($resultText)
{
    // Clean inputs
    $jsonStr = extractJSON($resultText);

    // Force cleaning immediately so we fix encoding/quotes before any decode attempt
    $jsonStr = cleanBadJSON($jsonStr);

    // Decode (with invalid UTF-8 ignore)
    $analysis = json_decode($jsonStr, true, 512, JSON_INVALID_UTF8_IGNORE);

    if (json_last_error() !== JSON_ERROR_NONE) {
        // Log the exact bad content for debugging
        logDebug("JSON Error: " . json_last_error_msg());
        logDebug("Bad Content Hex: " . bin2hex(substr($jsonStr, 0, 50)));
        logDebug("Full Bad Content: " . $jsonStr);

        throw new Exception('Failed to parse AI response as JSON: ' . json_last_error_msg() . '. Raw: ' . substr($jsonStr, 0, 100) . '...');
    }

    // Validate required fields
    $requiredFields = ['fit_score', 'matched_skills', 'missing_skills', 'recommendations', 'summary'];
    foreach ($requiredFields as $field) {
        if (!isset($analysis[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }

    // Validate data types
    if (!is_numeric($analysis['fit_score'])) {
        $analysis['fit_score'] = 0;
    }

    // Ensure arrays are actually arrays
    $arrayFields = ['matched_skills', 'missing_skills', 'recommendations'];
    foreach ($arrayFields as $field) {
        if (!isset($analysis[$field]) || !is_array($analysis[$field])) {
            $analysis[$field] = [];
        }
    }

    return $analysis;
}

/**
 * Extract JSON substring from text
 */
function extractJSON($text)
{
    $text = preg_replace('/```(?:json)?\s*(.*?)\s*```/s', '$1', $text);
    $start = strpos($text, '{');
    $end = strrpos($text, '}');

    if ($start !== false && $end !== false) {
        return substr($text, $start, $end - $start + 1);
    }
    return $text;
}


/**
 * Attempt to fix common JSON syntax errors
 */
function cleanBadJSON($json)
{
    // 0. Fix Encoding: Force UTF-8 and ignore invalid bytes
    if (function_exists('iconv')) {
        $json = iconv('UTF-8', 'UTF-8//IGNORE', $json);
    } else {
        $json = mb_convert_encoding($json, 'UTF-8', 'UTF-8');
    }

    // 0b. Fix Single Quotes: REMOVED (It breaks apostrophes like "there's")
    // $json = preg_replace("/'([^']+)'/", '"$1"', $json);

    // 1. Convert newlines to spaces (preserve structure)
    $json = str_replace(["\r\n", "\r", "\n"], " ", $json);

    // 2. Remove ALL Unicode Control Characters (Category: Other)
    // This catches \u2028 (Line Sep), \u2029 (Para Sep), and all non-printables
    $json = preg_replace('/[\p{C}]/u', '', $json);

    // 3. Fix trailing commas
    $json = preg_replace('/,\s*}/', '}', $json);
    $json = preg_replace('/,\s*]/', ']', $json);

    return $json;
}

/**
 * Log debug info
 */
function logDebug($message)
{
    file_put_contents(__DIR__ . '/debug_log.txt', date('[Y-m-d H:i:s] ') . $message . "\n", FILE_APPEND);
}

/**
 * Store analysis in database
 */
function storeAnalysis($resumeText, $jobDescription, $analysis)
{
    $conn = getDBConnection();

    $stmt = $conn->prepare(
        "INSERT INTO resume_analysis 
        (resume_text, job_description, fit_score, matched_skills, missing_skills, recommendations, summary) 
        VALUES (?, ?, ?, ?, ?, ?, ?)"
    );

    $fitScore = intval($analysis['fit_score']);
    $matchedSkills = json_encode($analysis['matched_skills']);
    $missingSkills = json_encode($analysis['missing_skills']);
    $recommendations = json_encode($analysis['recommendations']);
    $summary = $analysis['summary'];

    $stmt->bind_param(
        'ssissss',
        $resumeText,
        $jobDescription,
        $fitScore,
        $matchedSkills,
        $missingSkills,
        $recommendations,
        $summary
    );

    if (!$stmt->execute()) {
        throw new Exception('Failed to store analysis in database');
    }

    $analysisId = $conn->insert_id;

    $stmt->close();
    $conn->close();

    return $analysisId;
}
