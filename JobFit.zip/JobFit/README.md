# JobFit AI - AI-Powered Resume Analysis Tool

![JobFit AI](https://img.shields.io/badge/AI-Powered-blue) ![Status](https://img.shields.io/badge/Status-Hackathon%20Ready-success) ![License](https://img.shields.io/badge/License-MIT-green)

## 🎯 Overview

**JobFit AI** is an intelligent resume analysis tool that helps job seekers understand how well their resume matches a specific job description. Unlike traditional keyword-matching tools, JobFit AI uses **Google Gemini's advanced AI** to perform semantic analysis, understanding context and meaning to provide actionable insights.

### Key Features

- **🤖 Semantic AI Analysis**: Uses Google Gemini API for deep understanding, not just keyword matching
- **📊 Job Fit Score**: Get a clear percentage match (0-100%) between your resume and job description
- **✅ Matched Skills**: See which of your skills align with the job requirements
- **⚠️ Missing Skills**: Identify skill gaps that may be holding you back
- **💡 Smart Recommendations**: Receive AI-powered suggestions to improve your resume
- **📄 Multiple Formats**: Upload PDF or TXT files, or paste text directly
- **📱 Responsive Design**: Works seamlessly on desktop and mobile devices

## 🏗️ Tech Stack & Architecture

### Tech Stack
- **Frontend**: HTML5, CSS3, Vanilla JavaScript (pdf.js for local parsing)
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+ (Data Persistence)
- **AI Engine**: Google Gemini API (Secure Server-Side Calls)

### System Architecture
```mermaid
graph TD
    User((User)) -->|Upload Resume/JD| Frontend[Frontend: JS/HTML]
    Frontend -->|Local Extraction| PDFJS[PDF.js Utility]
    PDFJS -->|Clean Text| Frontend
    
    Frontend -->|POST Request| Backend[Backend: PHP]
    
    subgraph "Secure Cloud"
        Backend -->|Secure API Call| Gemini((Google Gemini AI))
        Gemini -->|JSON Analysis| Backend
    end
    
    Backend -->|Persistent Storage| DB[(MySQL Database)]
    Backend -->|Structured Data| Frontend
    
    Frontend -->|Dynamic Render| Results[Results Page: Score/Skills/Tips]
```

## 📋 Prerequisites

Before you begin, ensure you have:

1. **XAMPP** (or similar LAMP/WAMP stack)
   - Apache web server
   - PHP 7.4 or higher
   - MySQL 5.7 or higher

2. **Google Gemini API Key**
   - Get your free API key at: https://makersuite.google.com/app/apikey

3. **Modern Web Browser**
   - Chrome, Firefox, Safari, or Edge (latest versions)

## 🚀 Installation & Setup

### Step 1: Clone/Download the Project

```bash
# Place the JobFit folder in your XAMPP htdocs directory
# Path should be: C:\xampp\htdocs\JobFit (Windows)
# or /Applications/XAMPP/htdocs/JobFit (Mac)
```

### Step 2: Create the Database

1. Open **phpMyAdmin** (http://localhost/phpmyadmin)
2. Click on "Import" tab
3. Choose file: `sql/database.sql`
4. Click "Go" to import

**OR** run this command in MySQL:

```bash
mysql -u root -p < sql/database.sql
```

This will create:
- Database named `jobfit`
- Table `resume_analysis` with all required fields

### Step 3: Configure the Application

1. Open `backend/config.php`
2. Update the following settings:

```php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Your MySQL password (usually empty for XAMPP)
define('DB_NAME', 'jobfit');

// Google Gemini API Configuration
define('GEMINI_API_KEY', 'YOUR_ACTUAL_API_KEY_HERE'); // REPLACE THIS!
```

⚠️ **IMPORTANT**: Never commit `config.php` with real credentials to version control!

### Step 4: Start the Server

1. Open **XAMPP Control Panel**
2. Start **Apache** and **MySQL** modules
3. Verify they're running (green indicators)

### Step 5: Access the Application

Open your browser and navigate to:

```
http://localhost/JobFit
```

You should see the JobFit AI landing page!

## 📖 How to Use

### For Job Seekers

1. **Upload Your Resume**
   - Click the upload area or drag-and-drop your resume (PDF or TXT)
   - OR paste your resume text directly into the textarea

2. **Paste Job Description**
   - Copy the full job description from the job posting
   - Paste it into the "Job Description" field

3. **Analyze**
   - Click "Analyze Resume" button
   - Wait for AI analysis (typically 5-10 seconds)

4. **Review Results**
   - See your Job Fit Score (0-100%)
   - Review matched skills (what you have)
   - Identify missing skills (what you need)
   - Read AI recommendations to improve your resume

5. **Take Action**
   - Update your resume based on recommendations
   - Re-analyze to see improvement
   - Print or save results for reference

## 🎬 Demo Guide (For Hackathons)

### 2-Minute Demo Script

**Setup (Before Demo):**
1. Have XAMPP running
2. Prepare 2-3 sample resumes (PDF or text)
3. Have matching job descriptions ready
4. Open browser to `http://localhost/JobFit`

**Demo Flow:**

1. **Introduction (15 seconds)**
   - "JobFit AI helps job seekers understand resume-job alignment using AI"
   - "Unlike keyword matchers, we use semantic analysis"

2. **Upload Demo (30 seconds)**
   - Upload a sample resume
   - Paste a job description
   - Click "Analyze Resume"

3. **Results Showcase (60 seconds)**
   - Show the fit score with animated circle
   - Highlight matched skills (green badges)
   - Point out missing skills (red badges)
   - Read 1-2 AI recommendations

4. **Value Proposition (15 seconds)**
   - "This helps job seekers apply smarter, not harder"
   - "Increases interview chances by targeting the right skills"

**Pro Tips:**
- Use a resume with 60-80% match for best demo effect
- Prepare a "before/after" scenario showing improvement
- Have backup samples in case of API issues

## 🔧 Troubleshooting

### Common Issues

**1. "Database connection failed"**
- Verify MySQL is running in XAMPP
- Check database credentials in `config.php`
- Ensure `jobfit` database exists

**2. "Gemini API key not configured"**
- Open `backend/config.php`
- Replace `YOUR_GEMINI_API_KEY_HERE` with your actual API key
- Save the file

**3. "PDF text extraction failed"**
- Use text-based PDFs (not scanned images)
- Try uploading as TXT file instead
- Or paste text directly into the textarea

**4. "CORS errors in browser console"**
- Ensure you're accessing via `http://localhost/JobFit`
- Don't open HTML files directly (file://)
- Check Apache is running

**5. "Analysis takes too long"**
- Gemini API can take 5-15 seconds
- Check your internet connection
- Verify API key is valid and has quota

## 🏆 Why JobFit AI Wins Hackathons

### Technical Excellence
✅ Full-stack implementation (frontend + backend + database)  
✅ Real AI integration (not mocked responses)  
✅ Secure architecture (API keys server-side only)  
✅ Clean, professional code structure  
✅ Responsive, modern UI design  

### Problem-Solution Fit
✅ Solves a real problem job seekers face  
✅ Clear value proposition  
✅ Immediate, actionable results  
✅ Scalable to production  

### Demo-Friendly
✅ Works in 2-5 minutes  
✅ Visual, engaging interface  
✅ Clear before/after story  
✅ Judges can try it themselves  

## 📁 Project Structure

```
JobFit/
│
├── index.html              # Main landing page with upload form
├── results.html            # Analysis results display page
│
├── css/
│   └── style.css          # All styling (responsive, modern design)
│
├── js/
│   ├── main.js            # Form handling, file upload, API calls
│   └── results.js         # Results display and animations
│
├── backend/
│   ├── config.php         # Database and API configuration
│   ├── analyze.php        # Main analysis endpoint (Gemini integration)
│   └── upload.php         # File upload and text extraction
│
├── sql/
│   └── database.sql       # Database schema and table creation
│
└── README.md              # This file
```

## 🔒 Security Considerations

- ✅ API keys stored server-side only (never exposed to frontend)
- ✅ Prepared SQL statements prevent injection attacks
- ✅ File upload validation (type and size limits)
- ✅ Input sanitization on all user data
- ✅ CORS headers configured for local development

**For Production:**
- Use environment variables for sensitive config
- Enable HTTPS/SSL
- Add rate limiting to API endpoints
- Implement user authentication
- Add CSRF protection

## 🚀 Future Enhancements

- **User Accounts**: Save analysis history
- **Resume Builder**: Edit resume based on recommendations
- **Job Board Integration**: Auto-fetch job descriptions
- **Batch Analysis**: Compare one resume against multiple jobs
- **ATS Scoring**: Check Applicant Tracking System compatibility
- **Cover Letter Generator**: AI-powered cover letters

## 📄 License

This project is open source and available under the MIT License.

## 🙏 Acknowledgments

- **Google Gemini**: For powerful AI capabilities
- **XAMPP**: For easy local development environment
- **Open Source Community**: For inspiration and best practices

## 📞 Support

For issues or questions:
1. Check the Troubleshooting section above
2. Review `backend/config.php` for configuration
3. Check browser console for JavaScript errors
4. Verify Apache and MySQL are running
5. Contact me at ibrahimi107809@gmail.com or 07062616249

---

**Built with ❤️ for hackathons and job seekers everywhere**

*Last Updated: January 2026*
