/**
 * JobFit AI - Results Page JavaScript
 * Handles display and animation of analysis results
 */

// Load and display results on page load
document.addEventListener('DOMContentLoaded', () => {
    loadResults();
});

/**
 * Load results from sessionStorage
 */
function loadResults() {
    const resultsData = sessionStorage.getItem('analysisResults');

    if (!resultsData) {
        // No results found, redirect to home
        alert('No analysis results found. Please analyze a resume first.');
        window.location.href = 'index.html';
        return;
    }

    try {
        const results = JSON.parse(resultsData);
        displayResults(results);
    } catch (error) {
        alert('Error loading results: ' + error.message);
        window.location.href = 'index.html';
    }
}

/**
 * Display analysis results
 */
function displayResults(results) {
    // Display fit score with animation
    displayFitScore(results.fit_score);

    // Display summary
    document.getElementById('summaryText').textContent = results.summary;

    // Display matched skills
    displaySkills('matchedSkills', results.matched_skills, 'matched');
    document.getElementById('matchedCount').textContent = results.matched_skills.length;

    // Display missing skills
    displaySkills('missingSkills', results.missing_skills, 'missing');
    document.getElementById('missingCount').textContent = results.missing_skills.length;

    // Display recommendations
    displayRecommendations(results.recommendations);
}

/**
 * Display fit score with animated circle
 */
function displayFitScore(score) {
    const scoreValue = document.getElementById('scoreValue');
    const scoreCircle = document.getElementById('scoreCircle');

    // Animate score number
    animateValue(scoreValue, 0, score, 1500);

    // Animate circle
    const circumference = 2 * Math.PI * 90; // radius = 90
    const offset = circumference - (score / 100) * circumference;

    setTimeout(() => {
        scoreCircle.style.strokeDashoffset = offset;
    }, 100);

    // Change color based on score
    if (score >= 80) {
        scoreCircle.style.stroke = '#10b981'; // Green
    } else if (score >= 60) {
        scoreCircle.style.stroke = '#f59e0b'; // Orange
    } else {
        scoreCircle.style.stroke = '#ef4444'; // Red
    }
}

/**
 * Animate number value
 */
function animateValue(element, start, end, duration) {
    const range = end - start;
    const increment = range / (duration / 16); // 60fps
    let current = start;

    const timer = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = Math.round(current) + '%';
    }, 16);
}

/**
 * Display skills list
 */
function displaySkills(containerId, skills, type) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';

    if (skills.length === 0) {
        container.innerHTML = '<p style="color: var(--text-secondary); font-style: italic;">None identified</p>';
        return;
    }

    skills.forEach((skill, index) => {
        const badge = document.createElement('span');
        badge.className = `skill-badge ${type}`;
        badge.textContent = skill;
        badge.style.opacity = '0';
        badge.style.transform = 'translateY(10px)';
        container.appendChild(badge);

        // Animate in
        setTimeout(() => {
            badge.style.transition = 'all 0.3s ease';
            badge.style.opacity = '1';
            badge.style.transform = 'translateY(0)';
        }, index * 50);
    });
}

/**
 * Display recommendations
 */
function displayRecommendations(recommendations) {
    const list = document.getElementById('recommendationsList');
    list.innerHTML = '';

    if (recommendations.length === 0) {
        list.innerHTML = '<li>No specific recommendations at this time.</li>';
        return;
    }

    recommendations.forEach((recommendation, index) => {
        const li = document.createElement('li');
        li.textContent = recommendation;
        li.style.opacity = '0';
        li.style.transform = 'translateX(-20px)';
        list.appendChild(li);

        // Animate in
        setTimeout(() => {
            li.style.transition = 'all 0.4s ease';
            li.style.opacity = '1';
            li.style.transform = 'translateX(0)';
        }, index * 100 + 500);
    });
}
