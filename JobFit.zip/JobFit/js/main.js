/**
 * JobFit AI - Main JavaScript
 * Handles form submission, file upload, and API communication
 */

// Global variables
let uploadedFile = null;
let extractedText = '';

// DOM Elements
const analysisForm = document.getElementById('analysisForm');
const fileUploadArea = document.getElementById('fileUploadArea');
const resumeUpload = document.getElementById('resumeUpload');
const filePreview = document.getElementById('filePreview');
const fileName = document.getElementById('fileName');
const removeFileBtn = document.getElementById('removeFile');
const resumeText = document.getElementById('resumeText');
const jobDescription = document.getElementById('jobDescription');
const analyzeBtn = document.getElementById('analyzeBtn');
const errorMessage = document.getElementById('errorMessage');

// Initialize event listeners
document.addEventListener('DOMContentLoaded', () => {
    initializeFileUpload();
    initializeForm();
});

/**
 * Initialize file upload functionality
 */
function initializeFileUpload() {
    // Click to upload
    fileUploadArea.addEventListener('click', (e) => {
        if (e.target !== removeFileBtn && !uploadedFile) {
            resumeUpload.click();
        }
    });

    // File selection
    resumeUpload.addEventListener('change', handleFileSelect);

    // Remove file
    removeFileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        removeFile();
    });

    // Drag and drop
    fileUploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        fileUploadArea.style.borderColor = 'var(--primary-color)';
        fileUploadArea.style.backgroundColor = 'rgba(37, 99, 235, 0.05)';
    });

    fileUploadArea.addEventListener('dragleave', (e) => {
        e.preventDefault();
        fileUploadArea.style.borderColor = 'var(--border-color)';
        fileUploadArea.style.backgroundColor = 'transparent';
    });

    fileUploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        fileUploadArea.style.borderColor = 'var(--border-color)';
        fileUploadArea.style.backgroundColor = 'transparent';

        const files = e.dataTransfer.files;
        if (files.length > 0) {
            resumeUpload.files = files;
            handleFileSelect();
        }
    });
}

/**
 * Handle file selection
 */
async function handleFileSelect() {
    const file = resumeUpload.files[0];
    
    if (!file) return;

    // Validate file type
    const allowedTypes = ['application/pdf', 'text/plain'];
    if (!allowedTypes.includes(file.type)) {
        showError('Invalid file type. Please upload a PDF or TXT file.');
        return;
    }

    // Validate file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
        showError('File size exceeds 5MB limit.');
        return;
    }

    uploadedFile = file;
    
    // Show file preview
    fileName.textContent = file.name;
    fileUploadArea.querySelector('.upload-placeholder').style.display = 'none';
    filePreview.style.display = 'block';

    // Upload and extract text
    await uploadFile(file);
}

/**
 * Process file locally to extract text
 */
async function uploadFile(file) {
    try {
        showError(''); // Clear errors
        resumeText.disabled = true;
        resumeText.placeholder = "Processing file...";
        
        let text = '';

        if (file.type === 'application/pdf') {
            text = await extractTextFromPDF(file);
        } else {
            text = await extractTextFromTXT(file);
        }

        if (!text || text.trim().length === 0) {
            throw new Error('No text found in file. Please ensure it contains selectable text.');
        }

        extractedText = text;
        resumeText.value = extractedText;
        resumeText.disabled = true; // Disable manual editing when file is uploaded

    } catch (error) {
        showError('Error processing file: ' + error.message);
        removeFile();
    }
}

/**
 * Extract text from PDF using PDF.js
 */
async function extractTextFromPDF(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = async function() {
            try {
                const typedarray = new Uint8Array(this.result);
                const pdf = await pdfjsLib.getDocument(typedarray).promise;
                
                let fullText = '';
                
                // Iterate through all pages
                for (let i = 1; i <= pdf.numPages; i++) {
                    const page = await pdf.getPage(i);
                    const textContent = await page.getTextContent();
                    const pageText = textContent.items.map(item => item.str).join(' ');
                    fullText += pageText + '\n\n';
                }
                
                resolve(fullText);
            } catch (e) {
                reject(new Error('Failed to parse PDF: ' + e.message));
            }
        };
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsArrayBuffer(file);
    });
}

/**
 * Extract text from TXT file
 */
async function extractTextFromTXT(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = function() {
            resolve(this.result);
        };
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsText(file);
    });
}

/**
 * Remove uploaded file
 */
function removeFile() {
    uploadedFile = null;
    extractedText = '';
    resumeUpload.value = '';
    resumeText.value = '';
    resumeText.disabled = false;
    
    fileUploadArea.querySelector('.upload-placeholder').style.display = 'block';
    filePreview.style.display = 'none';
}

/**
 * Initialize form submission
 */
function initializeForm() {
    analysisForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await handleAnalysis();
    });
}

/**
 * Handle resume analysis
 */
async function handleAnalysis() {
    // Get resume text (from upload or textarea)
    const resume = extractedText || resumeText.value.trim();
    const job = jobDescription.value.trim();

    // Validate inputs
    if (!resume) {
        showError('Please upload a resume or paste resume text');
        return;
    }

    if (!job) {
        showError('Please paste the job description');
        return;
    }

    // Show loading state
    setLoadingState(true);
    showError('');

    try {
        const response = await fetch('backend/analyze.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                resume_text: resume,
                job_description: job
            })
        });

        const result = await response.json();

        if (result.success) {
            // Store results in sessionStorage
            sessionStorage.setItem('analysisResults', JSON.stringify(result.data));
            
            // Redirect to results page
            window.location.href = 'results.html';
        } else {
            showError(result.error || 'Analysis failed. Please try again.');
        }
    } catch (error) {
        showError('Error: ' + error.message + '. Please check your configuration.');
    } finally {
        setLoadingState(false);
    }
}

/**
 * Set loading state for submit button
 */
function setLoadingState(isLoading) {
    const btnText = analyzeBtn.querySelector('.btn-text');
    const btnLoader = analyzeBtn.querySelector('.btn-loader');

    if (isLoading) {
        btnText.style.display = 'none';
        btnLoader.style.display = 'flex';
        analyzeBtn.disabled = true;
    } else {
        btnText.style.display = 'block';
        btnLoader.style.display = 'none';
        analyzeBtn.disabled = false;
    }
}

/**
 * Show error message
 */
function showError(message) {
    if (message) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
    } else {
        errorMessage.style.display = 'none';
    }
}
