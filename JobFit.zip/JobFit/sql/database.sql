-- JobFit AI Database Schema
-- Create database and tables for resume analysis storage

-- Create database
CREATE DATABASE IF NOT EXISTS jobfit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE jobfit;

-- Resume Analysis Table
-- Stores all resume-job description analysis results
CREATE TABLE IF NOT EXISTS resume_analysis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    resume_text TEXT NOT NULL,
    job_description TEXT NOT NULL,
    fit_score INT NOT NULL,
    matched_skills JSON NOT NULL,
    missing_skills JSON NOT NULL,
    recommendations JSON NOT NULL,
    summary TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at),
    INDEX idx_fit_score (fit_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample query to verify table creation
-- SELECT * FROM resume_analysis ORDER BY created_at DESC LIMIT 10;
